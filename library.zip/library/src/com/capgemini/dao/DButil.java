package com.capgemini.dao;
import com.capgemini.exception.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DButil 
{
public static Connection con;
public static Connection getConnection() throws ClassNotFoundException,SQLException,FilenotfoundException
{


if(con == null)
{
	try{
	 
	String jdbcdriver= "oracle.jdbc.driver.OracleDriver";
	Class.forName(jdbcdriver);
	String jdbcURL = "jdbc:oracle:thin:@localhost:1521:XE";
	String userName = "System";
	String password = "Capgemini123";
	
	con = DriverManager.getConnection(jdbcURL, userName, password);
	
	}

	catch(SQLException se)
	{
		throw new FilenotfoundException("table does not exist "+se.getMessage());
	
	}
	
	
	
}
return con;
}
}
